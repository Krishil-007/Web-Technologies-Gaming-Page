console.log("Hello World");
var u_score = 0;
var comp_score = 0;
var u_score_span = document.getElementById("user-score");
var comp_score_span = document.getElementById("comp-score");
var Scorecard_div = document.querySelector(".Scorecard"); 
var result_div = document.querySelector(".result > p");
var rock_div = document.getElementById("r");
var paper_div = document.getElementById("p");
var scissor_div = document.getElementById("s");

function comp_move()
{
    var choices = ["r","p","s"];
    var pos = Math.floor(Math.random()*3);
    return choices[pos];
}

function decode(letter)
{
    if(letter === "r")
        return "Rock";
    if(letter === "p")
        return "Paper";
    return "Scissors";
}

function user_win(user, comp)
{
    u_score++;
    u_score_span.innerHTML = u_score;
    comp_score_span.innerHTML = comp_score;
    userchoice = document.getElementById(user);
    result_div.innerHTML = decode(user) + " Beats " + decode(comp) + ". You win!! 🔥🔥";
    userchoice.classList.add('on-win');
    setTimeout(function() {userchoice.classList.remove('on-win');}, 300);
}

function comp_win(user, comp)
{
    comp_score++;
    comp_score_span.innerHTML = comp_score;
    u_score_span.innerHTML = u_score;
    userchoice = document.getElementById(user);
    result_div.innerHTML = decode(comp) + " Beats " + decode(user) + ". You Lost";
    userchoice.classList.add('on-loss');
    setTimeout(function() {userchoice.classList.remove('on-loss');}, 300);
}

function draw(user, comp)
{
    userchoice = document.getElementById(user);
    userchoice.classList.add('on-draw');
    result_div.innerHTML = decode(user) + " equals " + decode(comp) + ". Its a Draw!!";
    setTimeout(function() {userchoice.classList.remove('on-draw');}, 300);
}

function result(user_choice)
{
    comp_choice = comp_move();
    switch(user_choice+comp_choice)
    {
        case "pr":
        case "rs":
        case "sp":
            user_win(user_choice, comp_choice);
            break;
        case "rp":
        case "sr":
        case "ps":
            comp_win(user_choice, comp_choice);
            break;
        case "pp":
        case "ss":
        case "rr":
            draw(user_choice, comp_choice);
            break;
    }
    console.log(user_choice);
    console
}

function clicked_rock()
{
    result("r");
}
function clicked_paper()
{
    result("p");
}
function clicked_scissor()
{
    result("s");
}

rock_div.addEventListener('click', clicked_rock);
paper_div.addEventListener('click', clicked_paper);
scissor_div.addEventListener('click', clicked_scissor);
